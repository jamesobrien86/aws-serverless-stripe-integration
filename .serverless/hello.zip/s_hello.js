
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jamesob86',
  applicationName: 'conclave-stripe-app',
  appUid: 'Wnrv1K2hHg0xPYXC9b',
  orgUid: '350280e5-98ef-4cc0-abff-4f05f91ed086',
  deploymentUid: 'e61b31db-ec7a-496c-927c-3f6e77eaf41e',
  serviceName: 'serverless-stripe-integration',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-stripe-integration-dev-hello', timeout: 12 };

try {
  const userHandler = require('./src/functions/hello/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}